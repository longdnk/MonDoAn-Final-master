# ADD Thu vien
:smiley:	Nhớ add thư viện, không add bảo sao nước biển lại mặn :smiley: \
</br>
<img src="https://user-images.githubusercontent.com/68718335/149338863-60fa2d3b-6751-4f1f-98f5-fb238aef914b.jpg" width="300" height="400" />
- pip install flask-wtf
- pip install flask-sqlalchemy
- pip install flask-migrate
- pip install flask_login
- pip install flask-ckeditor
